<!DOCTYPE html>
<html>
<head>
    <title>Sample Email</title>
</head>
<body>
<p><b>Name:</b> <?php echo e($name); ?></p>
<p><b>Email:</b> <?php echo e($email); ?></p>
<p><b>Number:</b> <?php echo e($number); ?></p>
<p><b>Company Name:</b> <?php echo e($companyName); ?></p>
</body>
</html>
<?php /**PATH /home/abubakar/Desktop/SA Systems/backend/resources/views/emails/sample.blade.php ENDPATH**/ ?>