<!DOCTYPE html>
<html>
<head>
    <title>Sample Email</title>
</head>
<body>
<p><b>Name:</b> {{ $name }}</p>
<p><b>Email:</b> {{ $email }}</p>
<p><b>Number:</b> {{ $number }}</p>
<p><b>Company Name:</b> {{ $companyName }}</p>
</body>
</html>
